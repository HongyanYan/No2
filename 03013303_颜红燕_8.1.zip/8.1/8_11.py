#one-mentional heat conduction problem

'''T1=input("please input T1")
print("the temperature of the internal surface is",T1)
TN=input("please input TN")
print("the temperature of the OUTSIDE surface is",TN)'''
T0=495#the temperature of the internal surface
TN=60#the temperature of the OUTSIDE surface

def Qjiauan(a,b):#每平方米炉墙每小时热损失
    q=0
    rezu=0
    for j in range(0,2):
        rezu+=a[j]/b[j]
    q=(T0-TN)/rezu
    print('qs=',q,'W/(m*m)')
    return q

def getData_TextFile(fileName):
    dataFile = open(fileName, 'r')
    DltaNumbda={'Dlta':[],'Numbda':[]}
    discardHeader = dataFile.readline()
    for line in dataFile:
        Dlta,Numbda= line.split()
        DltaNumbda['Dlta'].append(float(Dlta))
        DltaNumbda['Numbda'].append(float(Numbda))
    dataFile.close()
    return DltaNumbda

'''def Tjiauan(a,b,i):#每平方米炉墙每小时热损失
    Qjiauan(a,b)
    if i==0:
        return T0
    return Tjiauan(i-1)-q*a[i]/b[i]  '''  
      
DltaNumbda=getData_TextFile(r'./data.txt')
Qjiauan(DltaNumbda['Dlta'],DltaNumbda['Numbda'])
#Tjiauan(DltaNumbda['Dlta'],DltaNumbda['Numbda']，2)