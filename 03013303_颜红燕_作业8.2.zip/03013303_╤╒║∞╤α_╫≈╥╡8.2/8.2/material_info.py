# -*- coding: utf-8 -*-
import pickle
materialinfo = {}
FUNC_NUM =5
#写入文件
def write_file(value):
    file = open('material_info.txt', 'wb')
    file.truncate()#从文件的首行首字符开始截断，截断文件为n个字符；无n表示从当前位置起截断；截断之后n后面的所有字符被删除。
    pickle.dump(value, file, True)#将对象value保存到file中去
    file.close
#读取文件   
def read_file():
    '''定义一个全局变量'''
    global materialinfo
    file = open('material_info.txt', 'rb')
    materialinfo = pickle.load(file)
    file.close()#必须先关闭否则会出现pickle.load(file)会出现EOFError: Ran out of input
#搜索此种材料是否已经被记录   
def search_material():
    global materialinfo
    name = input('please input material\'s name:')
    if name in materialinfo:
        print('name:%s density:%s' % (name, materialinfo[name]))
    else:
        print('has no this material')
#删除此材料的信息        
def delete_material():
    global materialinfo
    name = input('please input material\'s name:')
    if name in materialinfo:
        materialinfo.pop(name)
        write_file(materialinfo)
    else:
        print('has no this material')
#添加材料信息   
def add_material():
    global materialinfo
    name = input('please input material\'s name:')
    density = input('please input density:')
    materialinfo[name] = density
    write_file(materialinfo)
#修改材料信息
def modifiy_material():
    global materialinfo
    name = input('please input material\'s name:')
    if name in materialinfo:
        density = input('please input material\'s density:')
        materialinfo[name] =density
    else:
        print('has no this name')
        
def show_all():
    global materialinfo
    for key, value in materialinfo.items():
        print('name:' + key + 'density:' + value)
 
func = {1 : search_material, \
    2 : delete_material, \
    3 : add_material, \
    4 : modifiy_material, \
    5 : show_all}

def menu():
    print('-----------------------------------------------');
    print('1 search material:')
    print('2 delete material:')
    print('3 add material:')
    print('4 modifiy material:')
    print('5 show all material')
    print('6 exit')
    print('-----------------------------------------------');

def init_data():
    global material
    file = open('material_info.txt', 'rb')
    materialinfo = pickle.load(file)
    #print(materialinfo)
    file.close()
    
init_data()
while True:
    menu()
    index = int(input())
    if index == FUNC_NUM + 1:
        exit()
    elif index < 1 or index > FUNC_NUM + 1:
        print('num is between 1-%d' % (FUNC_NUM + 1))
        continue
    #print(index)
    func[index]()

 