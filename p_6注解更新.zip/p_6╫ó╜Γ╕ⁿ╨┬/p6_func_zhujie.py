# -*- coding: utf-8 -*-
#引入绘图函数，此函数仿照MATLAB的函数形式的绘图接口，方便MATLAB用户过度到matplotlib包。
import matplotlib.pyplot as plt
import numpy as np
import math
#从statistics引入计算均值方差等函数
from  statistics import mean,stdev,pstdev,variance,pvariance
#PrettyTable的作用是用来将内容如表格方式整齐输出
from prettytable import PrettyTable
#glob 目录操作 查找目录内容
import glob
#定义一个存放文件名的列表
filenames=[]

xygroup=[]

xstagroup=[]
ystagroup=[]
rgroup=[]

lfit=[]
#从txt文件中获取数据
def getData_TextFile(fileName):
#文件更新模式：截断-写，读数据，执行一些计算，然后以写模式重新打开存在的文件
    dataFile = open(fileName, 'r')
#定义一个xy的字典，分别存放xy的数据列表
    xy={'x':[],'y':[]}
#File.readline()按行读取，以空格为切片点一次一行，在xy后面添加对象返回列表
    discardHeader = dataFile.readline()

    for line in dataFile:
        x,y= line.split()
        xy['x'].append(float(x))
        xy['y'].append(float(y))

    dataFile.close()

    return xy

def satData(x,y):
    #分别定义字典，存放xy的相关计算结果，初始化
    xsta={'avg':None,'stdev':None,'pstdev':None,'var':None,'pvar':None}
    ysta={'avg':None,'stdev':None,'pstdev':None,'var':None,'pvar':None}
    #给字典里每个对象逐次计算并赋值
    xsta['avg']=mean(x)
    ysta['avg']=mean(y)

    xsta['stdev']=stdev(x)
    ysta['stdev']=stdev(y)

    xsta['pstdev']=pstdev(x)
    ysta['pstdev']=pstdev(y)

    xsta['var']=variance(x)
    ysta['var']=variance(y)

    xsta['pvar']=pvariance(x)
    ysta['pvar']=pvariance(y)
#MATLAB中相关函数corrcoef
    r=np.corrcoef(x,y)[0, 1]

    return  xsta,ysta,r
#拟合数据
def fitData(x,y):
    #find linear fit
    '''y1=polyfit(x,y,N)，这里函数polyfit第一个参数传递的是拟合数据的自变量，第二个参数是因变量，
    第三个参数是拟合多项式的阶数，这个由我们给定。'''
    a,b = np.polyfit(x,y,1)
    predictedY = a*np.array(x) + b
    return a,b,predictedY

def plotData(x,y,a,b, predictedY,fileName):
    plt.plot(x,y, 'bo',
               label= fileName)
#图表名称
    plt.title(fileName)
#横坐标
    plt.xlabel('x')
#纵坐标
    plt.ylabel('y')

    plt.plot(x,predictedY,
               label = 'Y by\nlinear fit, y = '
               + str(round(a, 5))+'*x+'+str(round(b, 5)))
#loc告诉matplotlib要将图例放在哪。如果你不是吹毛求疵的话，“best”是不错的选择，因为它会选择最不碍事的位置。
    plt.legend(loc = 'best')

def processing_one_TextFile(filename):

    xy=getData_TextFile(filename)

    xsta,ysta,r=satData(xy['x'],xy['y'])

    a,b,predictedY=fitData(xy['x'],xy['y'])

    return xy,xsta,ysta,r,a,b,predictedY

def processing_data_TextFiles(filenames):

    for i in range(len(filenames)):

        xy,xsta,ysta,r,a,b,predictedY =processing_one_TextFile(filenames[i])

        xygroup.append(xy)

        xstagroup.append(xsta)
        ystagroup.append(ysta)

        rgroup.append(r)

        lfit.append({'a':a,'b':b,'preY':predictedY})

def processing_plot_TextFiles(filenames):
'''通过figsize参数可以指定绘图对象的宽度和高度，单位为英寸；dpi参数指定绘图对象的分辨率，即每英寸多少个像素，缺省值为80。
本例中所创建的图表窗口的宽度为12*80 = 960像素。但是用工具栏中的保存按钮保存下来的png图像的大小是1200*800像素。'''
    fig=plt.figure(figsize=(12.0,8.0))
''' #设置子图在画板中的布局，主要是子图上下边距（bottom、top），左右边距（left、right）'''
    fig.subplots_adjust(left=0.05,right=0.95,bottom=0.05,top=0.95)
#图标个数等于对应文件个数
    figcount=len(filenames)

    figcol=2
    figrow=math.ceil(figcount/figcol)

    for i in range(figcount):
        fig.add_subplot(figrow, figcol,i+1)
        plotData(xygroup[i]['x'],xygroup[i]['y'],
                 lfit[i]['a'],lfit[i]['b'],lfit[i]['preY'],filenames[i])

    plt.show()

def processing_table_TextFiles(filenames):

    table = PrettyTable(["data set",
                         "x-avg", "x-std", "x-pstd", "x-var","x-pvar",
                         "y-avg", "y-std", "y-pstd", "y-var","y-pvar",
                         "pearson_r"])

    table.align= "r" # right align
    table.padding_width = 1 # One space between column edges and contents (default)

    for i in range(len(filenames)):
        table.add_row(
                 [
                  filenames[i],
                   "%.3f" % xstagroup[i]['avg'],
                   "%.3f" % xstagroup[i]['stdev'],"%.3f" %xstagroup[i]['pstdev'],
                   "%.3f" % xstagroup[i]['var'],"%.3f" % xstagroup[i]['pvar'],
                   "%.3f" % ystagroup[i]['avg'],
                   "%.3f" % ystagroup[i]['stdev'],"%.3f" % ystagroup[i]['pstdev'],
                   "%.3f" % ystagroup[i]['var'],"%.3f" % ystagroup[i]['pvar'],
                   "%.3f" % rgroup[i]
                ])
    print(table)

if __name__ == '__main__':
#读取txt目录文件
    filenames=glob.glob(r'./Anscombe*.txt')
#调用函数，对文件进行数据，表格，图形处理 
    processing_data_TextFiles(filenames)
    processing_table_TextFiles(filenames)
    processing_plot_TextFiles(filenames)
